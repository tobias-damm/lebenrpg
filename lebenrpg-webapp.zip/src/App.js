import React, { useState } from "react";

export default function App() {
  const [name, setName] = useState("");
  const [started, setStarted] = useState(false);
  const [age, setAge] = useState(7);
  const [money, setMoney] = useState(5);
  const [happiness, setHappiness] = useState(5);
  const [hairColor, setHairColor] = useState("Braun");
  const [outfit, setOutfit] = useState("T-Shirt");
  const [expression, setExpression] = useState("Fröhlich");

  const startGame = () => setStarted(true);

  return (
    <div>
      {!started ? (
        <div>
          <h1>🎮 LebenRPG</h1>
          <input
            type="text"
            placeholder="Dein Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <button onClick={startGame} disabled={!name}>Spiel starten</button>
        </div>
      ) : (
        <div>
          <h2>👤 {name}, Alter: {age}</h2>
          <p>💰 {money}€ | 😄 Zufriedenheit: {happiness}</p>

          <div>
            <p><strong>Haarfarbe:</strong> {hairColor}</p>
            {["Blond", "Braun", "Schwarz", "Rosa"].map(color => (
              <button key={color} onClick={() => setHairColor(color)}>{color}</button>
            ))}
          </div>

          <div>
            <p><strong>Outfit:</strong> {outfit}</p>
            {["T-Shirt", "Hemd", "Pullover"].map(item => (
              <button key={item} onClick={() => setOutfit(item)}>{item}</button>
            ))}
          </div>

          <div>
            <p><strong>Gesichtsausdruck:</strong> {expression}</p>
            {["Fröhlich", "Traurig", "Neutral"].map(exp => (
              <button key={exp} onClick={() => setExpression(exp)}>{exp}</button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
